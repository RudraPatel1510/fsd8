// ── STEP 5 & 6: Auth Routes ─────────────────
// POST /api/auth/register  → Register a new drone pilot
// POST /api/auth/login     → Login and receive JWT token

const express  = require("express");
const router   = express.Router();
const User     = require("../models/User");
const bcrypt   = require("bcryptjs");
const jwt      = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");

// ── STEP 5: Register ────────────────────────
// Hashes the password before saving to database
router.post(
  "/register",
  [
    body("name").notEmpty().withMessage("Name is required"),
    body("email").isEmail().withMessage("Valid email is required"),
    body("password").isLength({ min: 6 }).withMessage("Password must be at least 6 characters"),
  ],
  async (req, res) => {
    // Validate inputs
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { name, email, password } = req.body;

      // Check if pilot already exists
      const existing = await User.findOne({ email });
      if (existing) {
        return res.status(400).json({ message: "Pilot already registered with this email" });
      }

      // Hash the password (salt rounds = 10)
      const hashed = await bcrypt.hash(password, 10);

      // Save new pilot to database
      const user = new User({ name, email, password: hashed });
      await user.save();

      res.status(201).json({ message: "🚁 Pilot registered successfully!", pilotId: user._id });
    } catch (err) {
      res.status(500).json({ message: "Server error", error: err.message });
    }
  }
);

// ── STEP 6: Login (JWT) ─────────────────────
// Returns a signed JWT token on successful login
// Token = identity proof — send it in all protected requests
router.post(
  "/login",
  [
    body("email").isEmail().withMessage("Valid email is required"),
    body("password").notEmpty().withMessage("Password is required"),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try {
      const { email, password } = req.body;

      // Find pilot by email
      const user = await User.findOne({ email });
      if (!user) {
        return res.status(404).json({ message: "Pilot not found. Please register first." });
      }

      // Compare entered password with stored hash
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({ message: "Incorrect password" });
      }

      // Sign JWT token with pilot's id and email
      // This token proves who the pilot is on future requests
      const token = jwt.sign(
        { id: user._id, email: user.email },
        process.env.JWT_SECRET,
        { expiresIn: "7d" }
      );

      res.json({
        message: "✅ Login successful!",
        token,
        pilot: { id: user._id, name: user.name, email: user.email },
      });
    } catch (err) {
      res.status(500).json({ message: "Server error", error: err.message });
    }
  }
);

// GET /api/auth/me  — get current logged-in pilot (protected)
const auth = require("../middleware/authMiddleware");
router.get("/me", auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select("-password");
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
