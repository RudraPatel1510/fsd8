// ── STEP 9: Drone Routes with Image Upload ──
// Uses Multer middleware to handle drone image uploads
// POST /api/drones      → Add new drone (protected, with image)
// GET  /api/drones      → Get all drones (public)
// GET  /api/drones/:id  → Get single drone (public)
// DELETE /api/drones/:id → Delete drone (protected)

const express = require("express");
const router  = express.Router();
const Drone   = require("../models/Drone");
const auth    = require("../middleware/authMiddleware");
const multer  = require("multer");

// ── Multer Storage Configuration ────────────
// Saves uploaded images to the /uploads folder
// Renames each file with a timestamp to avoid conflicts
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // save to /uploads directory
  },
  filename: (req, file, cb) => {
    // e.g. 1717000000000_drone.jpg
    cb(null, Date.now() + "_" + file.originalname);
  },
});

// Only allow image file types
const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image/")) {
    cb(null, true);
  } else {
    cb(new Error("Only image files are allowed"), false);
  }
};

const upload = multer({ storage, fileFilter });

// ── POST /api/drones ────────────────────────
// Add a new drone listing (auth required + image upload)
// Postman: form-data with name, model, price, category, image (File)
router.post("/", auth, upload.single("image"), async (req, res) => {
  try {
    const { name, model, price, category } = req.body;

    if (!name || !model || !price) {
      return res.status(400).json({ message: "Name, model and price are required" });
    }

    const drone = new Drone({
      name,
      model,
      price:    Number(price),
      category: category || "Photography",
      image:    req.file ? req.file.path : "",  // path to saved image
      addedBy:  req.user.id,                    // from JWT token
    });

    await drone.save();
    res.status(201).json({ message: "🚁 Drone added successfully!", drone });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// ── GET /api/drones ─────────────────────────
// Get all drones — public route, no token needed
router.get("/", async (req, res) => {
  try {
    const drones = await Drone.find()
      .populate("addedBy", "name email") // show pilot name+email
      .sort({ createdAt: -1 });
    res.json({ count: drones.length, drones });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// ── GET /api/drones/:id ─────────────────────
// Get a single drone by ID
router.get("/:id", async (req, res) => {
  try {
    const drone = await Drone.findById(req.params.id).populate("addedBy", "name email");
    if (!drone) return res.status(404).json({ message: "Drone not found" });
    res.json(drone);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// ── DELETE /api/drones/:id ──────────────────
// Delete a drone — auth required, only the pilot who added it can delete
router.delete("/:id", auth, async (req, res) => {
  try {
    const drone = await Drone.findById(req.params.id);
    if (!drone) return res.status(404).json({ message: "Drone not found" });

    // Check ownership
    if (drone.addedBy.toString() !== req.user.id) {
      return res.status(403).json({ message: "Not authorized to delete this drone" });
    }

    await drone.deleteOne();
    res.json({ message: "🗑️ Drone deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
