// ── STEP 8: Drone Model ─────────────────────
// Replaces the generic Product model with a drone-specific schema

const mongoose = require("mongoose");

const droneSchema = new mongoose.Schema(
  {
    name:      { type: String, required: true, trim: true },  // e.g. "DJI Mavic Pro"
    model:     { type: String, required: true },              // e.g. "Quadcopter X4"
    price:     { type: Number, required: true },              // price in INR
    category:  {
      type: String,
      enum: ["Racing", "Photography", "Military", "Delivery", "Agricultural"],
      default: "Photography",
    },
    image:     { type: String, default: "" },                 // uploaded image path
    inStock:   { type: Boolean, default: true },
    addedBy:   { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // pilot who added it
  },
  { timestamps: true }
);

module.exports = mongoose.model("Drone", droneSchema);
