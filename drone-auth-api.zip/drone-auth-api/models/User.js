// ── STEP 4: User Model ──────────────────────
// Stores pilot (user) accounts for the drone platform

const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name:     { type: String, required: true, trim: true },
    email:    { type: String, required: true, unique: true, lowercase: true },
    password: { type: String, required: true }, // stored as bcrypt hash
    role:     { type: String, enum: ["pilot", "admin"], default: "pilot" },
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
