// ─────────────────────────────────────────────
//  DRONE AUTH API — server.js
//  MERN Practical: JWT Auth, Image Upload, Payment
// ─────────────────────────────────────────────

const express   = require("express");
const mongoose  = require("mongoose");
const cors      = require("cors");
const dotenv    = require("dotenv");

dotenv.config();

const app = express();

// ── Middleware ──────────────────────────────
app.use(express.json());
app.use(cors());

// Serve uploaded drone images as static files
// e.g. GET http://localhost:5000/uploads/filename.jpg
app.use("/uploads", express.static("uploads"));

// ── STEP 2: Connect to MongoDB ──────────────
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("✅ MongoDB Connected"))
  .catch((err) => console.log("❌ DB Error:", err));

// ── Health Check ────────────────────────────
app.get("/", (req, res) => {
  res.json({ message: "🚁 Drone Auth API is Running" });
});

// ── Routes ──────────────────────────────────
app.use("/api/auth",   require("./routes/authRoutes"));
app.use("/api/drones", require("./routes/droneRoutes"));

// ── STEP 10: Mock Payment API ───────────────
// Simulates a drone purchase payment
// POST /api/payment  { "amount": 5000 }
app.post("/api/payment", (req, res) => {
  const { amount } = req.body;

  if (!amount) {
    return res.status(400).json({ status: "failed", message: "Amount is required" });
  }

  if (amount > 0) {
    res.json({
      status:      "success",
      message:     "🚁 Drone payment processed successfully",
      amountPaid:  amount,
      currency:    "INR",
      txnId:       "TXN" + Date.now(),
    });
  } else {
    res.status(400).json({
      status:  "failed",
      message: "Invalid amount. Must be greater than 0",
    });
  }
});

// ── Start Server ────────────────────────────
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
