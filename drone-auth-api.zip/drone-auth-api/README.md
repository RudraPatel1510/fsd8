# 🚁 Drone Auth API

**MERN Practical Lab — JWT Authentication, Image Upload & Payment API**
*Drone-themed implementation following the lab manual steps.*

---

## 📁 Project Structure

```
drone-auth-api/
├── models/
│   ├── User.js            # Pilot (user) schema — STEP 4
│   └── Drone.js           # Drone listing schema — STEP 8
├── routes/
│   ├── authRoutes.js      # Register + Login (JWT) — STEP 5, 6
│   └── droneRoutes.js     # Drone CRUD + Image Upload — STEP 9
├── middleware/
│   └── authMiddleware.js  # JWT protect middleware — STEP 7
├── uploads/               # Drone images saved here — STEP 9
├── server.js              # Main entry — STEP 1, 2, 10
├── .env                   # Environment variables
└── package.json
```

---

## ⚙️ Installation & Setup

```bash
# 1. Install dependencies
npm install

# 2. Make sure MongoDB is running locally
# Windows: net start MongoDB
# Mac/Linux: mongod

# 3. Start the server
npm run dev       # development
npm start         # production
```

Server runs at: **http://localhost:5000**

---

## 🌍 Environment Variables (`.env`)

```
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/drone_practical
JWT_SECRET=drone_jwt_secret_key_2024
```

---

## 🔌 API Endpoints

| Method | Endpoint            | Auth | Description                  |
|--------|---------------------|------|------------------------------|
| GET    | `/`                 | ❌   | Health check                 |
| POST   | `/api/auth/register`| ❌   | Register new pilot           |
| POST   | `/api/auth/login`   | ❌   | Login → returns JWT token    |
| GET    | `/api/auth/me`      | ✅   | Get current pilot info       |
| POST   | `/api/drones`       | ✅   | Add drone + image upload     |
| GET    | `/api/drones`       | ❌   | Get all drones               |
| GET    | `/api/drones/:id`   | ❌   | Get single drone             |
| DELETE | `/api/drones/:id`   | ✅   | Delete drone (owner only)    |
| POST   | `/api/payment`      | ❌   | Mock drone payment           |

---

## 🧪 Postman Testing Guide (FINAL TEST FLOW)

### STEP 1 — Register

**POST** `http://localhost:5000/api/auth/register`

Headers: `Content-Type: application/json`

Body (raw JSON):
```json
{
  "name": "Alex Drone Pilot",
  "email": "pilot@drone.com",
  "password": "drone123"
}
```

Expected Response:
```json
{
  "message": "🚁 Pilot registered successfully!",
  "pilotId": "..."
}
```

---

### STEP 2 — Login → Copy Token

**POST** `http://localhost:5000/api/auth/login`

Body (raw JSON):
```json
{
  "email": "pilot@drone.com",
  "password": "drone123"
}
```

Expected Response:
```json
{
  "message": "✅ Login successful!",
  "token": "eyJhbGci...",
  "pilot": { "id": "...", "name": "Alex Drone Pilot", "email": "pilot@drone.com" }
}
```

> **Copy the token value — you'll need it for protected routes.**

---

### STEP 3 — Add Drone (Protected + Image Upload)

**POST** `http://localhost:5000/api/drones`

Headers:
```
Authorization: <paste your token here>
```

Body: Select **form-data** in Postman:

| Key      | Type | Value            |
|----------|------|------------------|
| name     | Text | DJI Mavic Pro    |
| model    | Text | Quadcopter X4    |
| price    | Text | 85000            |
| category | Text | Photography      |
| image    | File | (select an image file) |

Expected Response:
```json
{
  "message": "🚁 Drone added successfully!",
  "drone": {
    "name": "DJI Mavic Pro",
    "model": "Quadcopter X4",
    "price": 85000,
    "category": "Photography",
    "image": "uploads/1717000000000_drone.jpg",
    ...
  }
}
```

---

### STEP 4 — Get All Drones (Public)

**GET** `http://localhost:5000/api/drones`

No headers needed.

Expected Response:
```json
{
  "count": 1,
  "drones": [{ "name": "DJI Mavic Pro", ... }]
}
```

---

### STEP 5 — Get Current Pilot (Protected)

**GET** `http://localhost:5000/api/auth/me`

Headers:
```
Authorization: <your token>
```

---

### STEP 6 — Mock Payment

**POST** `http://localhost:5000/api/payment`

Body (raw JSON):
```json
{
  "amount": 85000
}
```

Expected Response:
```json
{
  "status": "success",
  "message": "🚁 Drone payment processed successfully",
  "amountPaid": 85000,
  "currency": "INR",
  "txnId": "TXN1717000000000"
}
```

Test failure case (amount = 0):
```json
{ "amount": 0 }
```
```json
{ "status": "failed", "message": "Invalid amount. Must be greater than 0" }
```

---

## 🔑 JWT Flow Summary

```
Register → Password hashed with bcrypt → Saved to MongoDB
Login    → Password compared → JWT token signed with secret
Requests → Token sent in Authorization header → Middleware verifies → Route accessed
```

---

## 📦 Dependencies

| Package            | Purpose                        |
|--------------------|--------------------------------|
| express            | Web server framework           |
| mongoose           | MongoDB object modeling        |
| bcryptjs           | Password hashing               |
| jsonwebtoken       | JWT token generation/verify    |
| multer             | File/image upload handling     |
| express-validator  | Input validation               |
| cors               | Cross-Origin Resource Sharing  |
| dotenv             | Environment variable loading   |
| nodemon            | Auto-restart on file changes   |
