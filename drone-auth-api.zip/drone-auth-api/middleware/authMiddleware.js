// ── STEP 7: Auth Middleware ─────────────────
// Protects routes by verifying the JWT token
// Usage: add  auth  as middleware in any route you want to protect

const jwt = require("jsonwebtoken");

module.exports = (req, res, next) => {
  // Token must be sent in the Authorization header
  // Format: Authorization: <token>
  const token = req.header("Authorization");

  if (!token) {
    return res.status(401).json({ message: "🔒 Access denied. No token provided." });
  }

  try {
    // Verify the token using the secret key
    const verified = jwt.verify(token, process.env.JWT_SECRET);
    req.user = verified; // attach decoded user payload { id, email } to request
    next();              // pass control to the actual route handler
  } catch (err) {
    res.status(400).json({ message: "❌ Invalid or expired token." });
  }
};
